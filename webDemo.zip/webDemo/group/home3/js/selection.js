
        var pic;
        var tittle;

function enlarge(){
    if ($(manage).hasClass('act')) {
$(manage).removeClass('act');
$(manage).attr('title', 'Click to Enlarge Map');
}else{
  $(manage).addClass('act'); 
  $(manage).attr('title', 'Click to Shrink Map');  
}
}

        function adminLog1(){

$( document ).ready(function() {
 

    $("#adminLog1").click(function() {
        $('#prompting').text('To Access Event Pages, Please Login:');
        $('#prompting').append('<button type="button" style="float: right" class=" h1 btn btn-warning"  id="adminLog" onclick="adminLog()" class="btn btn-link">'+ "Or Click Here As Administrator" +'</button>');
         $('#label1').text('Email Address:');
        $('#input1').text('Enter Email address:');
        $('#input1').attr('type', 'email');
        $('#input1').attr('placeholder', 'Enter Email Address');
        $('#emailHelp').text("We'll never share your email with anyone else."); 
        $('#login').attr('action', 'javascript: passwordVali();');
    }); 

         

});
}
 function adminLog(){
    $( document ).ready(function() {
  $("#adminLog").click(function() {
        $('#prompting').text('Login As Administrator:');
        $('#prompting').append('<button type="button" style="float: right" class=" h1 btn btn-success"  id="adminLog1" onclick="adminLog1()" class="btn btn-link">'+ "Or Click Here As User" +'</button>');
                    $('#label1').text('Username:');
        $('#input1').text('Enter Username:');
        $('#input1').attr('type', 'text');
        $('#input1').attr('placeholder', 'Enter Username');
        $('#emailHelp').text('');
        $('#login').attr('action', 'javascript: passwordVali1();');
    });  
 
});
 
 
        }
        function select (){

        var opt = $('select').val();
         switch (opt) {
            case "0":
            window.open( "./protest.html");
                

                break;
            case "2":
         window.open( "./carAcci.html");
                
                break;
            case "1":
                window.open( "./fireCon.html");
                break;
            case "3":
               window.open( "./brawCerem.html");
                break;
            case "4":
                window.open( "./boyLantern.html");
                break;
            case "5":
                window.open( "./robbery.html");
                break;
            case "6":
               window.open( "./brokenPip.html");
        }
        }
        function select2 (){

        var opt = $('select').val();
         switch (opt) {
            case "0":
            window.open( "./protest2.html");
                

                break;
            case "2":
         window.open( "./carAcci2.html");
                
                break;
            case "1":
                window.open( "./fireCon2.html");
                break;
            case "3":
               window.open( "./brawCerem2.html");
                break;
            case "4":
                window.open( "./boyLantern2.html");
                break;
            case "5":
                window.open( "./robbery2.html");
                break;
            case "6":
               window.open( "./brokenPip2.html");
        }
        }

function moveAlert(){
$( document ).ready(function() {
 

    $("#move").click(function() {
        $('#aler').addClass('collapse');
    });  
});
    
}

function moveAlert1(){
$( document ).ready(function() {
 

    $("#move1").click(function() {
        $('#aler1').addClass('collapse');
    });  
});
    
}

function moveAlert2(){
$( document ).ready(function() {
 

    $("#move2").click(function() {
        $('#aler2').addClass('collapse');
    });  
});
    
}

function mapControl(){
$( document ).ready(function() {
 

    $("#showButton").click(function() {
        $('#map').toggle();
    });  
});
    
}
              function mapShow() {
                
        
    $(document).ready(function(){
        $("#showButton").click(function(){
            $("#map").show();
        });
      
    });

    }
              function mapHide() {
                
        
    $(document).ready(function(){
        $("#hideButton").click(function(){
            $("#map").hide();
        });
      
    });

              }


function passwordVali(){
    var email = $('#input1').val();
    var password = $('#password1').val();
    //alert(password);
    if(email=="a@a" && password==1111){
    
window.open( "group/home3/index.html", "_self");
    }
        if(email=="b@b" && password==2222){
    
window.open( "group/home3/index.html", "_self");
    }
        if(email=="c@c" && password==3333){
    
window.open( "group/home3/index.html", "_self");
    }
    //else{
$( document ).ready(function() {
 
 $('#aler').removeClass('collapse');   
});       
}

function passwordVali1(){
    var email = $('#input1').val();
    var password = $('#password1').val();
    //alert(password);
    if(email=="aaa" && password==1111){
    
window.open( "group/home3/index2.html", "_self");
    }
        if(email=="bbb" && password==2222){
    
window.open( "group/home3/index2.html", "_self");
    }
        if(email=="ccc" && password==3333){
    
window.open( "group/home3/index2.html", "_self");
    }
    //else{
$( document ).ready(function() {
 
 $('#aler').removeClass('collapse');   
});       
}

function addComment(){
var comment = $('#newComment').val();
var date = new Date();
var a = "Posted by Anonymous on " + date;
$( '#divComment').append("<p>" + comment + "</p>");
//$( '#divComment').append( comment);
//$( '#divComment').append( "</p>");
$( '#divComment').append( "<small>" + a +  "</small>");

$( '#divComment').append( "<hr>");
}

function changePassword(){

var email = $('#email2').val();
    if(email=="") {
  $( document ).ready(function() {
 
 $('#aler2').removeClass('collapse'); 
 $('#aler1').addClass('collapse');
  
});

    }else{
        $( document ).ready(function() {
 
 $('#aler1').removeClass('collapse'); 
   $('#aler2').addClass('collapse');
});
    }
$
 
}

function showForm(){
$( document ).ready(function() {
 

    $("#clickForm").click(function() {
        $('#swapForm').toggle();
    });  
});

}

function showForm1(){
   $(document).ready(function(){
        $("#clickForm").click(function(){
            $("#swapForm").show();
        });
      
    });

}



function changePassword1(){
//alert("Incorrect email or password!");

$( '#swapForm').append( "<form  action='javascript: passwordVali();'>");
$( '#swapForm').append( "<div>").attr("class", "form-group");
$( '#swapForm').append( "<h2>Request Password Reset</h2>");

$( '#swapForm').append( "<label>Email address</label>").attr("for", "exampleInputEmail1");
$( '#swapForm').append( "<input type='email'  aria-describedby='emailHelp' placeholder= 'Enter Email address:' >").attr("id", "email2").attr("class","form-control");
$( '#swapForm').append( "<small>We'll never share your email with anyone else.</small>");
$( '#swapForm').append( "<button type='submit' >Submit</button>").attr("class", "btn btn-primary");
$( '#swapForm').append( "</div></form>");

 
}

function changeEventText(){

 
    $( document ).ready(function() {
        $("#change13").click(function(){
var comment = $('#cText').text();
    $('#newComment').val(comment);
    $('#x').addClass('collapse');
    
  
    $('#cTextEditor').removeClass('collapse');
    }); 
    }); 
}

function cTextChange(){
    
       $( document ).ready(function() {
        $("#change29").click(function(){
    var comment = $('#cTextArea').val();
      $('#x').removeClass('collapse');
      $('#cTextEditor').addClass('collapse'); 
    $('#cText').text(comment);
    
       }); 
    });
}

  function passwordVali5(){
$('#aler5').removeClass('collapse');

  }

  function moveAlert5(){
$( document ).ready(function() {
 

    $("#move5").click(function() {
        $('#aler5').addClass('collapse');
    });  
});
    
}